module.exports = {
 __depends__: [
        require('diagram-js/lib/features/popup-menu'),
	 require('diagram-js/lib/features/replace'),
        require('diagram-js/lib/features/selection'),
	require('bpmn-js/lib/features/context-pad/ContextPadProvider')
	       ],
  __init__: [ 'customRenderer', 'paletteProvider', 'customRules', 'customUpdater', 'customreplaceMenuProvider', 'bpmnReplace' ],
  elementFactory: [ 'type', require('./CustomElementFactory') ],
  customRenderer: [ 'type', require('./CustomRenderer') ],
  paletteProvider: [ 'type', require('./CustomPalette') ],
  customRules: [ 'type', require('./CustomRules') ],
  customUpdater: [ 'type', require('./CustomUpdater') ],
  customreplaceMenuProvider: [ 'type', require('./CustomReplaceMenuProvider') ],
  bpmnReplace: [ 'type', require('./CustomBpmnReplace') ]
   };
