var config = require('./Config');

module.exports = function (grunt) {

    require('load-grunt-tasks')(grunt);

    var path = require('path');

    /**
     * Resolve external project resource as file path
     */
    function resolvePath(project, file) {
        return path.join(path.dirname(require.resolve(project)), file);
    }

    // project configuration
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        config: {
            sources: 'app',
            dist: 'dist'
        },

        jshint: {
            src: [
                ['<%=config.sources %>']
            ],
            options: {
                jshintrc: true
            }
        },

        browserify: {
            options: {
                browserifyOptions: {
                    // make sure we do not include browser shims unnecessarily
//                    builtins: false,  // commented out because of problem: scroll-tabs can not find module "events"
                    insertGlobalVars: {
                        process: function () {
                            return 'undefined';
                        },
                        Buffer: function () {
                            return 'undefined';
                        }
                    },
                    debug: true
                },
                transform: [['stringify', {extensions: ['.bpmn', '.xml', '.css']}]]
            },
            watch: {
                options: {
                    watch: true
                },
                files: {
                    '<%= config.dist %>/app.js': ['<%= config.sources %>/app.js']
                }
            },
            app: {
                files: {
                    '<%= config.dist %>/app.js': ['<%= config.sources %>/app.js']
                }
            }
        },

        copy: {
            diagram_js: {
                files: [
                    {
                        src: resolvePath('diagram-js', 'assets/diagram-js.css'),
                        dest: '<%= config.dist %>/css/diagram-js.css'
                    }
                ]
            },
            bpmn_js: {
                files: [
                    {
                        expand: true,
                        cwd: resolvePath('bpmn-js', 'assets'),
                        src: ['**/*.*', '!**/*.js'],
                        dest: '<%= config.dist %>/vendor'
                    }
                ]
            },
            app: {
                files: [
                    {
                        expand: true,
                        cwd: '<%= config.sources %>/',
                        src: ['**/*.*', '!**/*.js'],
                        dest: '<%= config.dist %>'
                    }
                ]
            }
        },

        less: {
          options: {
            dumpLineNumbers: 'comments',
            paths: [
              'node_modules'
            ]
          },

          styles: {
            files: {
              'dist/css/app.css': 'app/styles/app.less',
              'dist/css/hint.min.css': 'app/styles/hint.min.css'
            }
          }
        },

        uglify: {
            options: {
              mangle: false
            },
            my_target: {
                files: {
                    'dist/app.min.js': ['dist/app.js']
                }
            }
        },

        watch: {
            samples: {
                files: ['<%= config.sources %>/**/*.*'],
                tasks: ['copy:app']
            },
            less: {
                files: [
                  'app/styles/**/*.less',
                  'node_modules/bpmn-js-properties-panel/styles/**/*.less',
                  'node_modules/bpmn-js-embedded-comments/assets/*.css'
                ],
                tasks: [
                  'less'
                ]
            }
        },
        connect: {
	            options: {
               		port: config.localhost.port,
        		base: '.',
        		hostname: config.localhost.host,
        		protocol: 'http',
        		 open: true            
			},
		livereload: {
                options: {
                    open: true,
                    base: [
                        '<%= config.dist %>'
                    ]
                }
            }
                   
	}
    });

    // tasks
    grunt.registerTask('build', ['copy', 'less', 'uglify', 'browserify:app']);

    grunt.registerTask('auto-build', [
        'copy',
        'less',
        'browserify:watch',
        'uglify',
        'connect:livereload',
        'watch'
    ]);

    grunt.registerTask('default', ['jshint', 'build']);
};
